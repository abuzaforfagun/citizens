import { Component, OnInit } from '@angular/core';
import { fadeInAnimation } from '../_animations';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss'],
})
export class SignupComponent implements OnInit {
  pledges: any[];
  groups: any[];
  constructor() { }

  ngOnInit() {
    this.pledges = [
      {
        id: 1,
        text: 'Otext 1'
      }, {
        id: 2,
        text: 'Otext 2'
      }, {
        id: 3,
        text: 'Otext 3'
      },
    ];

    this.groups = [
      {
        id: 1,
        text: 'Teacher'
      }, {
        id: 2,
        text: 'Student'
      }
    ]
  }

}
