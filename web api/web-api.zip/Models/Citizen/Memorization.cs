namespace web_api.Models
{
    public class Memorization
    {
        public int Id { get; set; }
        public string Name { get; set; }
        
    }
}