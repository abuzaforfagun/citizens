using System.Collections.Generic;
using web_api.Models;
using Dapper;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;
using web_api.Models.Citizen;
using System.Linq;
using Microsoft.AspNetCore.Mvc;

namespace web_api.Presistance
{
    public class CitizenRepository
    {
        private string connectionString;

        public CitizenRepository(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("Production");

        }

        public IDbConnection Connection
        {
            get
            {
                return new SqlConnection(connectionString);
            }
        }
        public Citizen Add(Citizen citizen)
        {
            citizen.GuId = System.Guid.NewGuid();
            citizen.GenerateSH1Password();
            
            using (IDbConnection dbConnection = Connection)
            {
                dbConnection.Open();
                string query =
                $@"exec insert_citizens 
                '{citizen.GuId}', 
                '{citizen.Email}', 
                '{citizen.Username}', 
                '{citizen.Password}', 
                '{citizen.Name}', 
                '{citizen.Address}', 
                '{citizen.PhotoUrl}', 
                '{citizen.IsSponsorRequired}', 
                '{citizen.SupportEfforOf}', 
                '{citizen.SponsorStudent}'";
                // dbConnection.Execute(query);
                dbConnection.Query<int>(query, citizen.Id);
                // return dbConnection.Query<Citizen>(query, citizen).FirstOrDefault();
            }
            return citizen;
        }

        public Citizen Get(int id)
        {
            var citizen = new Citizen();
            using (IDbConnection dbConnection = Connection)
            {
                dbConnection.Open();
                string query = "SELECT * FROM Citizens WHERE id = @id";
                citizen = dbConnection.Query<Citizen>(query, new { id = id }).FirstOrDefault();
            }

            return citizen;
        }

        public List<Citizen> GetAll()
        {
            var list = new List<Citizen>();
            using (IDbConnection dbConnection = Connection)
            {
                dbConnection.Open();
                string query = "SELECT * FROM Citizens";
                list = dbConnection.Query<Citizen>(query).ToList();
            }
            return list;
        }

        public void Delete(int id)
        {
            using (IDbConnection dbConnection = Connection)
            {
                dbConnection.Open();
                string query = "DELETE FROM Citizens WHERE id = @id";
                dbConnection.Execute(query, id);
            }
        }
    }
}